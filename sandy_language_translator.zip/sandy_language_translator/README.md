# language-translator
#### This is a GUI application to translate text of one language to another made by python, GoogleTrans library and Textblob.
language support: ALL
<br><br>
## App Screenshots: 
![App Screenshot](/ss/langTranslate01.png)

<br>

###

To Run this project Clone it and install modules (googletrans, textblob) using:
```
pip install googletrans
```
```
pip install textblob
```

Make sure You have latest version of python installed. <br>
That's it. You are ready to go. To execute this project run:
```
python main.py
```
